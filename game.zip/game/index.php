<?php

include('menu.php');

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial - Meus Games</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="product.css">
</head>
<body>
    
  <div class="album py-5 bg-light">
    <div class="container">
        <h1>Página Inicial - Meus Games</h1> <br>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\carr.png" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text">Traffic Racer é um marco no gênero de corrida arcade sem fim. Dirija seu carro pelo trânsito intenso, ganhe dinheiro, aprimore seu carro e compre novos. Tente ser um dos motoristas mais rápidos nos rankings globais. Um novo conceito em corrida sem fim!</p>
              <div class="d-flex justify-content-between align-items-center">
               
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="imagens\Call-Of-Duty.jpg" alt="10" class="bd-placeholder-img card-img-top">

            <div class="card-body">
              <p class="card-text">Call of Duty é uma franquia de jogos eletrônicos de tiro em primeira pessoa publicado pela Activision. O primeiro título da série foi lançado em 2003 e começou nos computadores, mais tarde a série se expandiu para os mais variados consoles, portáteis e smartphones. </p>
              <div class="d-flex justify-content-between align-items-center">
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\gardenscapes.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text">Embarque em uma aventura ousada: vença níveis de agrupar 3, restaure e decore diferentes áreas no jardim, investigue os segredos ali escondidos e desfrute da companhia de divertidos personagens do jogo, inclusive Austin, seu mordomo! O que você está esperando? Construa o jardim dos seus sonhos!</p>
              <div class="d-flex justify-content-between align-items-center">
                
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\GTA.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text">GTA, refere-se à Grand Theft Auto, que é o termo em inglês para o roubo de automóveis de alto valor agregado, que em português seria o crime de Roubo Qualificado de Automóveis.sendo posteriormente gerenciada pelos irmãos Dan e Sam Houser, Leslie Benzies e Aaron Garbut.</p>
              <div class="d-flex justify-content-between align-items-center">
              
              </div>
            </div>
          </div>
        </div>
        <div class="col">
            
          <div class="card shadow-sm">
          <img src="imagens\thesims1.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text">The Sims é uma série de jogos eletrônicos de simulação de vida real criado pelo designer de jogos Will Wright e produzida pela Maxis. O primeiro jogo da série, The Sims, foi lançado em 4 de fevereiro de 2000. Os jogos da série The Sims são, em grande parte, jogos sandbox, pois não possuem objetivos definidos.</p>
              <div class="d-flex justify-content-between align-items-center">
              
              </div>
            </div>
          </div>
        </div>
    
        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\luta.jpg" alt="10" class="bd-placeholder-img card-img-top">
        
            <div class="card-body">
              <p class="card-text">Tekken é um série de jogos de luta criada, produzida e publicada pela Namco. Começando com o original Tekken em 1994, a série tem recebido muitas sequelas e actualizações assim como jogos paralelos. Tekken foi um dos primeiros jogos na altura que usava animação em 3D.</p>
              <div class="d-flex justify-content-between align-items-center">
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</main>

    
    
  



  
   

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</html>