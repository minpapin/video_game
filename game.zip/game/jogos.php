<?php

include('menu.php');

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TOP 5!</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="product.css">
</head>
<body>
    
  <div class="album py-5 bg-light">
    <div class="container">
        <h1>Top 5 melhores jogos!!</h1> <br>

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\fotnite.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text">Fortnite: Save the World e Fortnite: Battle Royale. Nos dois modos de jogar, você deve coletar materiais como madeira, tijolo e metal para a construção das suas fortificações. Além disso, armas estão disponíveis para que você consiga finalizar uma missão ou ser o último jogador no mapa.</p>
              <div class="d-flex justify-content-between align-items-center">
               
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="imagens\Counter.jpg" alt="10" class="bd-placeholder-img card-img-top">

            <div class="card-body">
              <p class="card-text">. Os jogadores competem em equipes e se posicionam como terroristas (T) e contra terroristas (CT). Os jogadores T devem implantar uma bomba no campo inimigo, enquanto os CT têm que desativá-la, destruindo inimigos e protegendo as possíveis vítimas. </p>
              <div class="d-flex justify-content-between align-items-center">
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\apex.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text">Nesse battle royale game, você precisa ser muito esperto, rápido e certeiro para levar a melhor. Cada Lenda disponível para o jogo tem sua própria personalidade (alguns são soldados, outros bandidos) e dispõe de habilidades únicas que, se bem exploradas por você, podem levar seu Esquadrão à vitória. </p>
              <div class="d-flex justify-content-between align-items-center">
                
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\minecraft.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text"> ideia básica desse jogo que conquista multidões é a construção por blocos. Os competidores precisam recolher recursos para que possam sobreviver, criando ambientes de maneira criativa. O jogo possui vários modos distintos, mas o principal é o "Survival". Nele, o objetivo é passar por diferentes fases, cada vez mais complicadas, até chegar à batalha final, com o Ender Dragon</p>
              <div class="d-flex justify-content-between align-items-center">
              
              </div>
            </div>
          </div>
        </div>
        <div class="col">
            
          <div class="card shadow-sm">
          <img src="imagens\pubg.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text"> No PUBGS, os competidores são lançados de paraquedas numa ilha sem absolutamente nada. Tudo, incluindo as próprias roupas e armas, tem que ser conquistado dentro do território, enquanto o jogador tenta superar os obstáculos e se manter na ilha o maior tempo possível.</p>
              <div class="d-flex justify-content-between align-items-center">
              
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="imagens\lol.jpg" alt="10" class="bd-placeholder-img card-img-top">
            <div class="card-body">
              <p class="card-text"> League of Legends é um jogo de estratégia em que duas equipes de cinco poderosos Campeões se enfrentam para destruir a base uma da outra. Escolha entre mais de 140 Campeões para realizar jogadas épicas, assegurar abates e destruir torres conforme você luta até a vitória.</p>
              <div class="d-flex justify-content-between align-items-center">
              
              </div>
            </div>
          </div>
        </div>
    
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</main>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</html>